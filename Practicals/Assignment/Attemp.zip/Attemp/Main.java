public class Main {
    public static void main(String[] args) {
        CarWash station = new CarWash();
        ThreadMain newT = new ThreadMain(station);
        newT.start();
    }
}
