public class ThreadMain extends Thread{

    private CarWash cWash;
    Thread t;
    static int num = 0;
    ThreadMain(CarWash c){
        cWash = c;
        t = new Thread(this, String.valueOf(num));
        num += 1;
    }
    public void run(){
        for(int i = 0 ; i < 7 ; i++)
            cWash.washCars();
    }
}
