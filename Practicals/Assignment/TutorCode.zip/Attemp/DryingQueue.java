public class DryingQueue extends Thread{
    Thread t = new Thread(this);

    
}
